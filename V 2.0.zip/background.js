// background.js (service worker)
// Controls tab management and injects content scripts on BOSS直聘 (zhipin.com).

// BOSS直聘: direct search URL with query param (no input typing).
const TARGET_ORIGIN = "https://www.zhipin.com";
const JOBS_SEARCH_PATH = "/web/geek/jobs";

function getJobsSearchUrl(query) {
  const q = (query || "").trim();
  const params = q ? `?query=${encodeURIComponent(q)}` : "";
  return `${TARGET_ORIGIN}${JOBS_SEARCH_PATH}${params}`;
}

/**
 * Promisified helpers for chrome.tabs.
 */
function queryTabs(queryInfo) {
  return new Promise((resolve) => chrome.tabs.query(queryInfo, resolve));
}

function createTab(createProperties) {
  return new Promise((resolve) => chrome.tabs.create(createProperties, resolve));
}

function updateTab(tabId, updateProperties) {
  return new Promise((resolve) =>
    chrome.tabs.update(tabId, updateProperties, resolve)
  );
}

chrome.runtime.onInstalled.addListener(() => {
  console.log("Job Automation Extension installed.");
});

/**
 * Find an open zhipin tab or create one; navigate to jobs search URL with query.
 * @param {string} [searchQuery] - Keyword for ?query= (e.g. "seo")
 * @returns {Promise<number>} tabId
 */
async function findOrCreateTargetTab(searchQuery) {
  const url = getJobsSearchUrl(searchQuery);
  const tabs = await queryTabs({ url: "*://www.zhipin.com/*" });

  if (tabs && tabs.length > 0) {
    const tab = tabs[0];
    await updateTab(tab.id, { active: true, url });
    return tab.id;
  }

  const newTab = await createTab({ url, active: true });
  return newTab.id;
}

/**
 * Inject helpers and content script into the given tab.
 */
async function injectAutomationScripts(tabId) {
  try {
    await chrome.scripting.executeScript({
      target: { tabId, allFrames: false },
      files: ["utils/helpers.js"],
    });

    await chrome.scripting.executeScript({
      target: { tabId, allFrames: false },
      files: ["content.js"],
    });

    console.log("Job automation scripts injected.");
  } catch (err) {
    console.error("Failed to inject scripts:", err);
  }
}

/**
 * Start the automation flow:
 *  - Find or open target tab and navigate to jobs?query=<keywords>
 *  - Wait until fully loaded, then inject scripts
 * @param {string} [searchQuery] - Keywords from popup (e.g. "seo")
 */
async function startAutomation(searchQuery) {
  const tabId = await findOrCreateTargetTab(searchQuery);

  chrome.tabs.get(tabId, (tab) => {
    if (chrome.runtime.lastError) {
      console.error(chrome.runtime.lastError.message);
      return;
    }

    if (tab.status === "complete") {
      injectAutomationScripts(tabId);
    } else {
      const listener = (updatedTabId, changeInfo) => {
        if (updatedTabId === tabId && changeInfo.status === "complete") {
          chrome.tabs.onUpdated.removeListener(listener);
          injectAutomationScripts(tabId);
        }
      };

      chrome.tabs.onUpdated.addListener(listener);
    }
  });
}

/**
 * Handle messages from popup and content scripts.
 */
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message?.type === "START_AUTOMATION") {
    const query = message.query != null ? String(message.query).trim() : "";
    startAutomation(query || undefined).catch((err) =>
      console.error("Error starting automation:", err)
    );
    sendResponse({ ok: true });
    return true;
  }

  if (message?.type === "AUTOMATION_STATUS") {
    console.log("Automation status:", message.status, message.details || "");
    
    // Forward logs to popup
    chrome.runtime.sendMessage({
      type: "LOG",
      message: message.message || `Status: ${message.status}`,
      level: message.level || 'info'
    }).catch(() => {});
    return;
  }

  if (message?.type === "AUTOMATION_DONE") {
    const count = message.appliedCount || 0;
    console.log(`Automation finished. Applied to ${count} jobs.`);

    chrome.runtime.sendMessage({
      type: "LOG",
      message: `Completed! Applied to ${count} jobs.`,
      level: 'success'
    }).catch(() => {});

    if (chrome.notifications) {
      chrome.notifications.create({
        type: "basic",
        iconUrl: "icons/icon128.png",
        title: "Job Automation Complete",
        message: `Applied to ${count} job(s).`,
      });
    }
  }
});

