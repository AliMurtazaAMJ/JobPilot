# Job Automation Extension (Chrome Manifest V3)

Automate job search and applications on **BOSS直聘 (zhipin.com)**.

This extension:

- Opens or focuses a tab on zhipin.com with your search query.
- Injects automation scripts into that tab.
- Finds job listings matching your keywords.
- Automatically clicks the "沟通" (Communicate) button for each job.
- Tracks applied jobs to avoid duplicates.

> **Note:** This extension is specifically built for BOSS直聘 (www.zhipin.com). To use it on other job sites, you'll need to update the selectors and logic.

---

## 1. File Structure

```text
Extension/
├─ manifest.json          # Extension configuration (Manifest V3)
├─ background.js          # Service worker: tab management + script injection
├─ content.js             # Runs inside zhipin.com, clicks 沟通 button
├─ utils/
│   └─ helpers.js         # DOM helpers + zhipin.com job extraction
├─ popup/
│   ├─ popup.html         # Popup UI for preferences + start button
│   ├─ popup.js           # Logic for saving prefs & triggering automation
│   └─ popup.css          # Styling for popup
├─ icons/
│   ├─ icon16.png         # Extension icons
│   ├─ icon48.png
│   └─ icon128.png
└─ README.md
```

---

## 2. BOSS直聘 Configuration

### 2.1 Target URL

The extension is configured for **BOSS直聘 (zhipin.com)**:

```js
const TARGET_ORIGIN = "https://www.zhipin.com";
const JOBS_SEARCH_PATH = "/web/geek/jobs";
```

Search is performed via URL query parameter: `/web/geek/jobs?query=<keywords>`

### 2.2 DOM Selectors

The `SELECTORS` object in `content.js` is configured for zhipin.com:

```js
const SELECTORS = {
  jobList: ".rec-job-list",
  jobCard: ".card-area",
  seenJobCard: ".card-area.is-seen",
  jobCardWrap: ".job-card-wrap",
  communicateBtn: ".op-btn.op-btn-chat",
};
```

**To adapt for other job sites:** Update these selectors using browser DevTools (Inspect Element).

---

## 3. How It Works

### 3.1 Background (`background.js`)

- Listens for `START_AUTOMATION` messages from the popup.
- Finds an existing zhipin.com tab or opens a new one.
- Navigates to `/web/geek/jobs?query=<keywords>` with the search query.
- Waits for the tab to finish loading.
- Injects `utils/helpers.js` and `content.js`.
- Shows a notification when automation completes.

### 3.2 Content Script (`content.js`)

- Loads user preferences from `chrome.storage.sync`:
  - `jobKeywords`
  - `maxApplicationsPerRun`
- Waits for job listings to load (search is already performed via URL).
- Collects `.card-area` elements and extracts job data.
- Builds unique job IDs from job card content.
- Checks previously applied job IDs to avoid duplicates.
- Automation flow:
  - **Step 1**: Detects `.card-area.is-seen` (seen job) and clicks `.op-btn.op-btn-chat` inside it.
  - **Step 2**: If no seen job exists, selects first `.card-area` without `.is-seen`, clicks `.job-card-wrap` to activate, then clicks `.op-btn.op-btn-chat`.
  - Waits 2 seconds between applications.
- Saves updated `appliedJobs` to storage.
- Sends status messages to background script.

### 3.3 Popup (`popup/popup.*`)

- Simple form to configure:
  - **Job Keywords** (e.g. "seo", "前端开发")
  - **Location** (stored but not currently used in URL search)
  - **Max applications per run** (default: 10)
- Saves preferences in `chrome.storage.sync`.
- Sends `START_AUTOMATION` with keywords to background when you click **Save & Start**.

### 3.4 Helpers (`utils/helpers.js`)

Reusable utility functions:

- `wait(ms)` – async delay.
- `$` / `$all` – safe DOM query wrappers.
- `clickElement(selector, root)` – scrolls into view and clicks.
- `typeInto(selector, value, root)` – sets input values and triggers events.
- `waitForElement(selector, timeoutMs)` – waits for elements to appear.
- `getJobFromCard(card)` – extracts job data from a `.card-area` element.
- `getJobList(root)` – returns array of all jobs on the page.

---

## 4. Permissions & Storage

`manifest.json` requests:

- `tabs` – to find or open the target tab.
- `activeTab` – to interact with the current tab.
- `storage` – to store preferences and applied job history.
- `scripting` – to inject `helpers.js` and `content.js`.
- `notifications` – to notify when automation completes.

Storage keys in `chrome.storage.sync`:

- `jobKeywords`
- `location`
- `maxApplicationsPerRun`
- `appliedJobs` (array of job IDs that were already applied)

---

## 5. Loading the Extension in Chrome

1. Open Chrome and go to `chrome://extensions/`.
2. Turn on **Developer mode** (top-right toggle).
3. Click **Load unpacked**.
4. Select the `Extension` folder.
5. The extension should appear in your toolbar.
6. Pin it via the puzzle-piece icon for easy access.

---

## 6. Running the Automation

1. Click the extension icon to open the popup.
2. Enter:
   - **Job Keywords** (e.g. `seo`, `前端开发`, `产品经理`)
   - **Location** (optional, for reference)
   - **Max applications per run** (e.g. `10`)
3. Click **Save & Start**.
4. The extension will:
   - Open or focus a zhipin.com tab with your search query.
   - Wait for job listings to load.
   - Click "沟通" on up to 10 unapplied jobs.
5. A notification will show how many jobs were contacted.
6. Applied job IDs are saved to prevent duplicate applications.

---

## 7. Features & Limitations

### Current Features
- Automatic job search via URL query parameter
- Duplicate prevention using job ID tracking
- Configurable application limit per run
- Browser notifications on completion
- Prioritizes seen jobs (`.is-seen`) before unseen jobs
- Smart job card activation and communication flow

### Limitations
- Only works on BOSS直聘 (zhipin.com)
- Location filter not implemented in URL search
- No salary or experience filtering
- 2-second delay between applications (may need adjustment)

### Future Improvements
- Add Start/Stop toggle in popup
- Implement location filtering in search URL
- Add salary and experience filters
- Export applied jobs history
- Handle multi-step communication flows
- Support additional job sites

