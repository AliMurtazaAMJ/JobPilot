// content.js
// Runs inside BOSS直聘 (zhipin.com) and performs job extraction + apply flow.

console.log("Job automation content script loaded.");

// BOSS直聘 selectors (zhipin.com)
const SELECTORS = {
  jobList: ".rec-job-list",
  jobCard: ".card-area",
  seenJobCard: ".card-area.is-seen",
  jobCardWrap: ".job-card-wrap",
  communicateBtn: ".op-btn.op-btn-chat",
};

const DEFAULT_PREFERENCES = {
  jobKeywords: "",
  location: "",
  maxApplicationsPerRun: 10,
};

/**
 * Storage helpers (chrome.storage.sync).
 */
function getPreferences() {
  return new Promise((resolve) => {
    chrome.storage.sync.get(DEFAULT_PREFERENCES, (items) => {
      resolve({
        jobKeywords: items.jobKeywords || DEFAULT_PREFERENCES.jobKeywords,
        location: items.location || DEFAULT_PREFERENCES.location,
        maxApplicationsPerRun:
          Number(items.maxApplicationsPerRun) ||
          DEFAULT_PREFERENCES.maxApplicationsPerRun,
      });
    });
  });
}

function getAppliedJobs() {
  return new Promise((resolve) => {
    chrome.storage.sync.get({ appliedJobs: [] }, (items) => {
      resolve(items.appliedJobs || []);
    });
  });
}

function saveAppliedJobs(appliedJobs) {
  return new Promise((resolve) => {
    chrome.storage.sync.set({ appliedJobs }, () => resolve());
  });
}

/**
 * Build a unique job ID from card element.
 */
function buildJobId(cardEl) {
  const wrap = cardEl.querySelector(SELECTORS.jobCardWrap);
  if (!wrap) return null;
  const text = wrap.textContent.trim();
  return text || null;
}

/**
 * Find the communicate button.
 */
function getCommunicateButton() {
  return $(SELECTORS.communicateBtn);
}

/**
 * Get seen job card.
 */
function getSeenJobCard() {
  return $(SELECTORS.seenJobCard);
}

/**
 * Select a job by clicking the card wrap, then click communicate button.
 */
async function selectJobAndCommunicate(cardEl) {
  if (!cardEl) return false;
  const wrap = cardEl.querySelector(SELECTORS.jobCardWrap);
  if (!wrap) return false;
  wrap.click();
  await wait(800);
  const btn = getCommunicateButton();
  if (!btn) return false;
  btn.click();
  return true;
}

/**
 * Click communicate button on seen job (button is in detail panel, not inside card).
 */
async function communicateWithSeenJob() {
  const btn = $(SELECTORS.communicateBtn);
  if (!btn) return false;
  btn.click();
  return true;
}

/**
 * Main automation sequence.
 */
async function runJobAutomation() {
  try {
    const prefs = await getPreferences();
    const appliedJobs = await getAppliedJobs();
    const appliedSet = new Set(appliedJobs);

    chrome.runtime.sendMessage({
      type: "AUTOMATION_STATUS",
      message: "Automation started",
      level: "info"
    });

    chrome.runtime.sendMessage({
      type: "AUTOMATION_STATUS",
      message: "Waiting for job list to load...",
      level: "info"
    });
    
    await waitForElement(SELECTORS.jobList, 10000);
    await wait(2000);
    
    const cards = Array.from($all(SELECTORS.jobCard));
    chrome.runtime.sendMessage({
      type: "AUTOMATION_STATUS",
      message: `Found ${cards.length} job cards`,
      level: cards.length > 0 ? "success" : "warning"
    });

    if (cards.length === 0) {
      chrome.runtime.sendMessage({
        type: "AUTOMATION_STATUS",
        message: "No job cards found. Check selectors or page.",
        level: "error"
      });
      chrome.runtime.sendMessage({
        type: "AUTOMATION_DONE",
        appliedCount: 0,
      });
      return;
    }

    let appliedCount = 0;

    while (appliedCount < prefs.maxApplicationsPerRun) {
      const seenCard = getSeenJobCard();
      let cardToUse = null;
      let jobId = null;

      if (seenCard) {
        jobId = buildJobId(seenCard);
        if (jobId && !appliedSet.has(jobId)) {
          chrome.runtime.sendMessage({
            type: "AUTOMATION_STATUS",
            message: "Processing seen job...",
            level: "info"
          });
          const communicated = await communicateWithSeenJob();
          if (communicated) {
            appliedSet.add(jobId);
            appliedCount += 1;
            chrome.runtime.sendMessage({
              type: "AUTOMATION_STATUS",
              message: `Applied to job ${appliedCount}/${prefs.maxApplicationsPerRun}`,
              level: "success"
            });
          } else {
            chrome.runtime.sendMessage({
              type: "AUTOMATION_STATUS",
              message: "Communicate button not found, trying unseen jobs",
              level: "warning"
            });
          }
          await wait(2000);
          if (communicated) continue;
        }
      }

      for (const card of cards) {
        if (card.classList.contains("is-seen")) continue;
        const id = buildJobId(card);
        if (id && !appliedSet.has(id)) {
          cardToUse = card;
          jobId = id;
          break;
        }
      }

      if (!cardToUse || !jobId) {
        chrome.runtime.sendMessage({
          type: "AUTOMATION_STATUS",
          message: "No more unapplied jobs found",
          level: "info"
        });
        break;
      }

      chrome.runtime.sendMessage({
        type: "AUTOMATION_STATUS",
        message: "Selecting and communicating with job...",
        level: "info"
      });
      
      const communicated = await selectJobAndCommunicate(cardToUse);
      if (communicated) {
        appliedSet.add(jobId);
        appliedCount += 1;
        chrome.runtime.sendMessage({
          type: "AUTOMATION_STATUS",
          message: `Applied to job ${appliedCount}/${prefs.maxApplicationsPerRun}`,
          level: "success"
        });
      } else {
        chrome.runtime.sendMessage({
          type: "AUTOMATION_STATUS",
          message: "Failed to communicate with job",
          level: "warning"
        });
      }

      await wait(2000);
    }

    await saveAppliedJobs(Array.from(appliedSet));

    chrome.runtime.sendMessage({
      type: "AUTOMATION_DONE",
      appliedCount,
    });
  } catch (err) {
    chrome.runtime.sendMessage({
      type: "AUTOMATION_STATUS",
      message: `Error: ${err.message || String(err)}`,
      level: "error"
    });
  }
}

// Ensure DOM is ready before running.
if (document.readyState === "loading") {
  document.addEventListener("DOMContentLoaded", () => {
    runJobAutomation();
  });
} else {
  runJobAutomation();
}

