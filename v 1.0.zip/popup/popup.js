// popup/popup.js
// Handles user preferences and triggers automation via the background script.

const DEFAULTS = {
  jobKeywords: "",
  location: "",
  maxApplicationsPerRun: 10,
};

function loadPreferences() {
  chrome.storage.sync.get(DEFAULTS, (items) => {
    document.getElementById("jobKeywords").value =
      items.jobKeywords || DEFAULTS.jobKeywords;
    document.getElementById("location").value =
      items.location || DEFAULTS.location;
    document.getElementById("maxApplicationsPerRun").value =
      items.maxApplicationsPerRun || DEFAULTS.maxApplicationsPerRun;
  });
}

function savePreferences(prefs) {
  return new Promise((resolve) => {
    chrome.storage.sync.set(prefs, () => resolve());
  });
}

function setStatus(text) {
  const el = document.getElementById("status");
  if (el) el.textContent = text;
}

function addLog(message, type = 'info') {
  const logContainer = document.getElementById("logContainer");
  const logContent = document.getElementById("logContent");
  
  if (logContainer && logContent) {
    logContainer.style.display = 'block';
    
    const entry = document.createElement('div');
    entry.className = `log-entry ${type}`;
    const timestamp = new Date().toLocaleTimeString();
    entry.textContent = `[${timestamp}] ${message}`;
    
    logContent.appendChild(entry);
    logContent.scrollTop = logContent.scrollHeight;
  }
}

function clearLogs() {
  const logContent = document.getElementById("logContent");
  if (logContent) {
    logContent.innerHTML = '';
  }
}

document.addEventListener("DOMContentLoaded", () => {
  loadPreferences();

  // Listen for log messages from background
  chrome.runtime.onMessage.addListener((message) => {
    if (message?.type === "LOG") {
      addLog(message.message, message.level || 'info');
    }
  });

  const form = document.getElementById("prefs-form");
  form.addEventListener("submit", async (event) => {
    event.preventDefault();

    clearLogs();

    const prefs = {
      jobKeywords: document.getElementById("jobKeywords").value.trim(),
      location: document.getElementById("location").value.trim(),
      maxApplicationsPerRun: Number(
        document.getElementById("maxApplicationsPerRun").value || 10
      ),
    };

    await savePreferences(prefs);
    setStatus("Preferences saved. Starting automation...");
    addLog("Starting automation...", 'info');

    chrome.runtime.sendMessage(
      { type: "START_AUTOMATION", query: prefs.jobKeywords },
      (response) => {
        if (chrome.runtime.lastError) {
          setStatus("Failed to start automation.");
          addLog("Failed to start: " + chrome.runtime.lastError.message, 'error');
          return;
        }
        if (response && response.ok) {
          setStatus("Automation started. Check the job tab.");
          addLog("Automation started successfully", 'success');
        } else {
          setStatus("Automation could not be started.");
          addLog("Could not start automation", 'error');
        }
      }
    );
  });
});

